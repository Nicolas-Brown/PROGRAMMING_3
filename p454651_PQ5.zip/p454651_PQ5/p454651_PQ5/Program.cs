﻿using System;

namespace p454651_PQ5
{
    class Program
    {
        public static void Main()
        {
            ConsoleKeyInfo cki;

            Console.Clear();

            //Establish an event handler to process key press events.
            Console.CancelKeyPress += new ConsoleCancelEventHandler(myHandler);
            while (true)
            {
                Console.WriteLine("press any key to increase the number or press CTRL+C to interrupt the read operation:");

                for(int i = 0; i < 100; i++)
                {
                    Console.WriteLine("Current number: " + i);
                    cki = Console.ReadKey(true);
                }
            }
        }

        private static void myHandler(object sender, ConsoleCancelEventArgs args)
        {
            Console.WriteLine("\n" + "The read operation has been interrupted.");
            Console.WriteLine($"Cancel property: {args.Cancel}");

            //set the Cancel property to true
            args.Cancel = true;

            Console.WriteLine($"Cancel property: {args.Cancel}");
            Console.WriteLine("resume read operation \n");
        }
    }
}
