﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace p454651_PQ2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        BinaryTree tree;
        List<string> nameList = new List<string> {"Nic", "David", "Kyle", "Noah", "Josh", "Jack", "Corey", "Matt", "Zac", "Lily"};

        private void btn_Add_Click(object sender, RoutedEventArgs e)
        {
            //checks to see if text box is empty
            if(!string.IsNullOrEmpty(txt_Add.Text))
            {
                //adds item to namelist
                nameList.Add(txt_Add.Text);
                //generates tree
                btn_Generate_Click(sender, e);
            }
        }

        private void btn_Remove_Click(object sender, RoutedEventArgs e)
        {
            //checks to see if text box is empty
            if (!string.IsNullOrEmpty(txt_Remove.Text))
            {
                //checks to see if namelist has the text from the textbox
                if (nameList.Contains(txt_Remove.Text))
                {
                    //removes item to namelist
                    nameList.Remove(txt_Remove.Text);
                    //generates tree
                    btn_Generate_Click(sender, e);
                }
                else
                {
                    //shows pop up box
                    MessageBox.Show("Not found");
                }
            }
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            //checks to see if text box is empty
            if (!string.IsNullOrEmpty(txt_Search.Text))
            {
                //checks to see if namelist has the text from the textbox
                if (nameList.Contains(txt_Search.Text))
                {
                    string goal = txt_Search.Text;
                    string message = "path found for " + goal;
                    string path = null;
                    //searches the tree
                    path = tree.Search(goal, path);
                    //clears the listbox
                    lst_Display.Items.Clear();
                    //shows path in listbox
                    lst_Display.Items.Add(message);
                    lst_Display.Items.Add(path);
                }
                else
                {
                    //shows pop up box
                    MessageBox.Show("Not found");
                }
            }
        }

        private void btn_Generate_Click(object sender, RoutedEventArgs e)
        {
            tree = new BinaryTree(null);
            //clears listbox
            lst_Display.Items.Clear();
            //generates array
            string[] stringArray = nameList.ToArray();
            //gets lenght of array
            int length = stringArray.Length;
            //generates tree
            tree.CreateTreeFromArray(stringArray, 0, length - 1);
            //adds tree to listbox
            foreach (string name in stringArray)
            {
                lst_Display.Items.Add(name);
            }
        }
    }
}
