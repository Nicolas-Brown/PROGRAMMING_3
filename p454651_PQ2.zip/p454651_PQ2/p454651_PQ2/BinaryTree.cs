﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p454651_PQ2
{
    class BinaryTree
    {
        public string Node
        {
            get;
            set;
        }

        public BinaryTree Left
        {
            get;
            set;
        }

        public BinaryTree Right
        {
            get;
            set;
        }

        public BinaryTree(string node)
        {
            this.Node = node;
            this.Left = null;
            this.Right = null;
        }

        public void Insert(string newNode)
        {
            string currentNode = this.Node;

            //If empty put in new data
            if (currentNode == null)
            {
                Node = newNode;
            }
            else
            {
                //Compare for placement
                if (currentNode.CompareTo(newNode) > 0)
                {
                    if (this.Left == null)
                    {
                        this.Left = new BinaryTree(newNode);
                    }
                    else
                    {
                        this.Left.Insert(newNode);
                    }
                }
                else if (currentNode.CompareTo(newNode) < 0)
                {
                    if (this.Right == null)
                    {
                        this.Right = new BinaryTree(newNode);
                    }
                    else
                    {
                        this.Right.Insert(newNode);
                    }
                }
            }
        }

        public void CreateTreeFromArray(string[] newData, int start, int end)
        {
            if (start > end)
            {
                return;
            }

            int mid = (start + end) / 2;
            Insert(newData[mid]);

            CreateTreeFromArray(newData, start, mid - 1);
            CreateTreeFromArray(newData, mid + 1, end);
        }

        public string Search(string goal, string path)
        {
            string compareNode = Node.ToLower();
            string compareGoal = goal.ToLower();
            if (compareNode.CompareTo(compareGoal) == 0)
            {
                return Node;
            }
            else if (compareNode.CompareTo(compareGoal) > 0)
            {
                path += $" {this.Node} > {this.Left.Search(goal, path)}";
                return path;
            }
            else
            {
                path += $" {this.Node} > {this.Right.Search(goal, path)}";
                return path;
            }
        }
    }
}