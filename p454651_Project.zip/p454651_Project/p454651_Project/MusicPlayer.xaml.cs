﻿using CsvHelper;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace p454651_Project
{
    /// <summary>
    /// Interaction logic for MusicPlayer.xaml
    /// </summary>
    public partial class MusicPlayer : Window
    {
        static LinkedList<string> musicList = new LinkedList<string>();
        static List<string> usortedList = new List<string>();
        static List<string> sortedList = new List<string>();
        static List<Playlist> playlist;
        

        public MusicPlayer()
        {
            InitializeComponent();
            //opens a file dialog to get music
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            if (openFileDialog.ShowDialog() == true)
            {
                foreach (String file in openFileDialog.FileNames)
                {
                    //saves music to unsorted list
                    Media.Source = new Uri(openFileDialog.FileName);

                    usortedList.Add(file);
                }
            }
            //merge sorts the unsorted list
            sortedList = MergeSort(usortedList);
            foreach (string file in sortedList)
            {
                //adds the sorted list to the doubly linked list
                musicList.AddLast(file);
            }
            //displays the songs
            ShowLinkedList();
            //selects the first song
            string temp = musicList.First();
            lst_Music.SelectedItem = temp;
            Media.Pause();

        }
        
        private void btn_Play_Click(object sender, RoutedEventArgs e)
        {
            //plays the song
            Media.Play();
        }

        private void btn_Pause_Click(object sender, RoutedEventArgs e)
        {
            //pauses the song
            Media.Pause();
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            //pauses the song
            Media.Pause();
            //selects the first song if the list box is selcting the first song
            if (lst_Music.SelectedIndex == 0)
            {
                string temp = musicList.First();
                Media.Source = new Uri(temp);
                lst_Music.SelectedItem = temp;
            }
            //selects the next song
            else
            {
                int tempNum = lst_Music.SelectedIndex;
                tempNum--;
                lst_Music.SelectedIndex = tempNum;
                string temp = lst_Music.SelectedItem.ToString();
                Media.Source = new Uri(temp);
            }
            //plays song
            Media.Play();
        }

        private void btn_Forward_Click(object sender, RoutedEventArgs e)
        {
            //pauses the song
            Media.Pause();
            //selects the last song if the list box is selcting the first song
            if (lst_Music.SelectedIndex == musicList.Count)
            {
                Media.Pause();
                string temp = musicList.Last();
                Media.Source = new Uri(temp);
                lst_Music.SelectedItem = temp;
                Media.Play();
            }
            //selects the previous song
            else
            {
                int tempNum = lst_Music.SelectedIndex;
                tempNum++;
                lst_Music.SelectedIndex = tempNum;
                string temp = lst_Music.SelectedItem.ToString();
                Media.Source = new Uri(temp);
            }
            //plays song
            Media.Play();
        }

        private void btn_Start_Click(object sender, RoutedEventArgs e)
        {
            //pauses the song
            Media.Pause();
            //selects the first song
            string temp = musicList.First();
            Media.Source = new Uri(temp);
            lst_Music.SelectedItem = temp;
            //plays song
            Media.Play();
        }

        private void btn_End_Click(object sender, RoutedEventArgs e)
        {
            //pauses the song
            Media.Pause();
            //selects the last song
            string temp = musicList.Last();
            Media.Source = new Uri(temp);
            lst_Music.SelectedItem = temp;
            //plays song
            Media.Play();
        }

        private void btn_Close_Click(object sender, RoutedEventArgs e)
        {
            //writes file to csv
            WriteFile();
            //closes music player
            System.Windows.Application.Current.Shutdown();
        }

            private void ShowLinkedList()
        {
            // clear list box
            lst_Music.Items.Clear();
            // display linked list
            foreach (string song in musicList)
            {
                lst_Music.Items.Add(song);
            }
        }

        private static List<string> MergeSort(List<string> unsorted)
        {
            if (unsorted.Count <= 1)
                return unsorted;

            List<string> left = new List<string>();
            List<string> right = new List<string>();

            int middle = unsorted.Count / 2;
            for (int i = 0; i < middle; i++)  //Dividing the unsorted list
            {
                left.Add(unsorted[i]);
            }
            for (int i = middle; i < unsorted.Count; i++)
            {
                right.Add(unsorted[i]);
            }

            left = MergeSort(left);
            right = MergeSort(right);
            return Merge(left, right);
        }

        private static List<string> Merge(List<string> left, List<string> right)
        {
            List<string> result = new List<string>();

            while (left.Count > 0 || right.Count > 0)
            {
                if (left.Count > 0 && right.Count > 0)
                {
                    //Comparing First two elements to see which is smaller
                    if (left.First().CompareTo(right.First()) <= 0)  
                    {
                        result.Add(left.First());
                        left.Remove(left.First());      
                    }
                    else
                    {
                        result.Add(right.First());
                        right.Remove(right.First());
                    }
                }
                else if (left.Count > 0)
                {
                    result.Add(left.First());
                    left.Remove(left.First());
                }
                else if (right.Count > 0)
                {
                    result.Add(right.First());

                    right.Remove(right.First());
                }
            }
            return result;
        }

        private void lst_Music_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Media.Pause();
            String find = lst_Music.SelectedItem.ToString();
            txt_Search.Text = lst_Music.SelectedItem.ToString();
            Media.Source = new Uri(find);
            Media.Play();
        }

        public void WriteFile()
        {
            StreamWriter writer = new StreamWriter("playlist.csv");
            CsvWriter csv = new CsvWriter(writer);
            foreach (string file in sortedList)
            {
                csv.WriteRecords(file);
            }
            writer.Close();
        }

        private void btn_Search_Click(object sender, RoutedEventArgs e)
        {
            //plays the song that is entered into the text box
            var index = sortedList.BinarySearch(txt_Search.Text);
            lst_Music.SelectedIndex = index;
            string temp = lst_Music.SelectedItem.ToString();
            Media.Source = new Uri(temp);
        }

        private void btn_Help_Click(object sender, RoutedEventArgs e)
        {
            //displays message box with message
            string message = "Play: play the currently selected song" + "\n" + "Pasue: pauses the currently selected song" + "\n" + "Back: plays the previous" + "\n" +
                "Forward: plays the next song" + "\n" + "Start: plays the first song" + "\n" + "End: plays the last song" + "\n" + "Search: search for the song that is typed into the text box"
                + "\n" + "Close and save to CSV: save the playlist to a csv and closes the music player";
            MessageBox.Show(message);
        }
    }
}
