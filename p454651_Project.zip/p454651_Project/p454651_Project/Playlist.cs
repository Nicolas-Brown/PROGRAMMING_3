﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p454651_Project
{
    class Playlist
    {
        public string Name;

        public Playlist(string Name)
        {
            this.Name = Name;
        }
    }
}
