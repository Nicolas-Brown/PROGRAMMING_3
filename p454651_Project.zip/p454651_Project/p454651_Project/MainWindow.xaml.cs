﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace p454651_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            setUser("p454651");
            setPass("Password");
        }

        private void btn_Login_Click(object sender, RoutedEventArgs e)
        {
            bool userLogin = getUser();
            bool passLogin = getPass();
            if (passLogin == true && userLogin == true)
            {
                MusicPlayer mPlayer = new MusicPlayer();
                mPlayer.Show();
                this.Close();
            }
        }

        void SavePass(string password)
        {
            //Save password to local file
            string file = "password.txt";
            StreamWriter streamWriter = new StreamWriter(file, false);
            streamWriter.WriteLine(password);
            streamWriter.Close();
        }

        string RetrievePass()
        {
            //Retrieve password from local file
            string file = "password.txt";
            string line = "";
            string password = "";
            StreamReader streamReader = new StreamReader(file);
            while ((line = streamReader.ReadLine()) != null)
            {
                password = line;
            }
            streamReader.Close();
            return password;
        }

        void SaveUser(string username)
        {
            //Save password to local file
            string file = "username.txt";
            StreamWriter streamWriter = new StreamWriter(file, false);
            streamWriter.WriteLine(username);
            streamWriter.Close();
        }

        string RetrieveUser()
        {
            //Retrieve password from local file
            string file = "username.txt";
            string line = "";
            string username = "";
            StreamReader streamReader = new StreamReader(file);
            while ((line = streamReader.ReadLine()) != null)
            {
                username = line;
            }
            streamReader.Close();
            return username;
        }

        bool getPass()
        {
            Hasher hasher = new Hasher();
            string comparePass = RetrievePass();
            if (hasher.Verification(comparePass, txt_Password.Text))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        bool getUser()
        {
            Hasher hasher = new Hasher();
            string compareUser = RetrieveUser();
            if (hasher.Verification(compareUser, txt_Username.Text))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        void setUser(string User)
        {
            Hasher hasher = new Hasher();
            string hashedUser = hasher.Hashing(User);
            try
            {
                SaveUser(hashedUser);
            }
            catch (Exception e)
            {
            }
        }

        void setPass(string Pass)
        {
            Hasher hasher = new Hasher();
            string hashedPass = hasher.Hashing(Pass);
            try
            {
                SavePass(hashedPass);
            }
            catch (Exception e)
            {
            }
        }
    }
}
