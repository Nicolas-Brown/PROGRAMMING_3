﻿using System;
using System;
using System.Security.Cryptography;

namespace p454651_Project
{
    class Hasher
    {
        //method to hash enetered value
        public string Hashing(string value)
        {
            byte[] salt;
            new RNGCryptoServiceProvider().GetBytes(salt = new byte[16]);

            var pbkdf2 = new Rfc2898DeriveBytes(value, salt, 10000);
            byte[] hash = pbkdf2.GetBytes(20);

            byte[] hashbytes = new byte[36];
            Array.Copy(salt, 0, hashbytes, 0, 16);
            Array.Copy(hash, 0, hashbytes, 16, 20);

            string Hashed = Convert.ToBase64String(hashbytes);
            return Hashed;
        }

        //mehod to verify hashed value
        public bool Verification(string hashed, string entered)
        {
            //extract the bytes
            byte[] hashBytes = Convert.FromBase64String(hashed);


            //get the salt
            byte[] salt = new byte[16];
            Array.Copy(hashBytes, 0, salt, 0, 16);

            //compute the hash on the value the user entered
            var pbkdf2 = new Rfc2898DeriveBytes(entered, salt, 10000);
            byte[] hash = pbkdf2.GetBytes(20);



            for (int i = 0; i < 20; i++)
            {
                if (hashBytes[i + 16] != hash[i])
                {
                    return false;
                }
            }
            return true;
        }
    }
}
