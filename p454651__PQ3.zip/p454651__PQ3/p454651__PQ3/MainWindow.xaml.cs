﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace p454651__PQ3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            txtBubble.Clear();
            txtInbuilt.Clear();
            txtMerge.Clear();
        }
        int length = 1000000;
        int minNum = 10000;
        int maxNum = 10000001;
        int temp = 0;
        int[] numArray = new int[1000000];

        static public void merge(int[] numArray, int p, int q, int r)
        {
            int i, j, k;
            int n1 = q - p + 1;
            int n2 = r - q;
            int[] L = new int[n1];
            int[] R = new int[n2];
            for (i = 0; i < n1; i++)
            {
                L[i] = numArray[p + i];
            }
            for (j = 0; j < n2; j++)
            {
                R[j] = numArray[q + 1 + j];
            }
            i = 0;
            j = 0;
            k = p;
            while (i < n1 && j < n2)
            {
                if (L[i] <= R[j])
                {
                    numArray[k] = L[i];
                    i++;
                }
                else
                {
                    numArray[k] = R[j];
                    j++;
                }
                k++;
            }
            while (i < n1)
            {
                numArray[k] = L[i];
                i++;
                k++;
            }
            while (j < n2)
            {
                numArray[k] = R[j];
                j++;
                k++;
            }
        }
        static public void mergeSort(int[] numArray, int p, int r)
        {
            if (p < r)
            {
                int q = (p + r) / 2;
                mergeSort(numArray, p, q);
                mergeSort(numArray, q + 1, r);
                merge(numArray, p, q, r);
            }
        }

        public void create() 
        {
            for (int i = 0; i < length; i++)
            {
                Random rnd = new Random();
                int number = rnd.Next(minNum, maxNum);
                numArray[i] = number;
            }
        }

        private void Btn_Inbuilt_Click(object sender, RoutedEventArgs e)
        {
            var watch = new System.Diagnostics.Stopwatch();
            for(int u = 0; u < 10; u++)
            {
                create();
                watch.Start();
                Array.Sort(numArray);
                watch.Stop();
                txtInbuilt.Text += $"Execution Time: " + watch.ElapsedMilliseconds.ToString() + " ms" + "\n";
                watch.Reset();
            }
        }

        private void btn_Merge_Click(object sender, RoutedEventArgs e)
        {
            var watch = new System.Diagnostics.Stopwatch();
            for (int u = 0; u < 10; u++)
            {
                create();
                watch.Start();
                mergeSort(numArray, 0, length - 1);
                watch.Stop();
                txtMerge.Text += $"Execution Time: "+ watch.ElapsedMilliseconds.ToString() + " ms" + "\n";
                watch.Reset();
            }
        }

        private void Btn_Bubble_Click(object sender, RoutedEventArgs e)
        {
            var watch = new System.Diagnostics.Stopwatch();
            create();
            watch.Start();
            for (int j = 0; j <= length - 2; j++)
            {
                for (int i = 0; i <= length - 2; i++)
                {
                    if (numArray[i] > numArray[i + 1])
                    {
                        temp = numArray[i + 1];
                        numArray[i + 1] = numArray[i];
                        numArray[i] = temp;
                    }
                }
            }
            watch.Stop();
            txtBubble.Text += $"Execution Time: " + watch.ElapsedMilliseconds.ToString() + " ms" + "\n";
            watch.Reset();
        }
    }
}
