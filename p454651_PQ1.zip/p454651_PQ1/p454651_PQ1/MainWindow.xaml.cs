﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace p454651_PQ1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    
    public partial class MainWindow : Window
    {
        static LinkedList<string> musicList = new LinkedList<string>();
        public MainWindow()
        {
            InitializeComponent();
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            if (openFileDialog.ShowDialog() == true)
            {
                foreach(String file in openFileDialog.FileNames)
                {
                    Media.Source = new Uri(openFileDialog.FileName);

                    musicList.AddLast(file);
                    ShowLinkedList();
                }
            }
        }


        private void Btn_Play_Click(object sender, RoutedEventArgs e)
        {
            Media.Play();
        }

        private void Btn_Pause_Click(object sender, RoutedEventArgs e)
        {
            Media.Pause();
        }

        private void Btn_Back_Click(object sender, RoutedEventArgs e)
        {
            Media.Pause();
            if (lst_Music.SelectedIndex == 0)
            {
                string temp = musicList.First();
                Media.Source = new Uri(temp);
                lst_Music.SelectedItem = temp;
            } else
            {
                int tempNum = lst_Music.SelectedIndex;
                tempNum--;
                lst_Music.SelectedIndex = tempNum;
                string temp = lst_Music.SelectedItem.ToString();
                Media.Source = new Uri(temp);
            }
            Media.Play();
        }

        private void Btn_Forward_Click(object sender, RoutedEventArgs e)
        {
            Media.Pause();
            if (lst_Music.SelectedIndex == musicList.Count)
            {
                Media.Pause();
                string temp = musicList.Last();
                Media.Source = new Uri(temp);
                lst_Music.SelectedItem = temp;
                Media.Play();
            }
            else
            {
                int tempNum = lst_Music.SelectedIndex;
                tempNum++;
                lst_Music.SelectedIndex = tempNum;
                string temp = lst_Music.SelectedItem.ToString();
                Media.Source = new Uri(temp);
            }
            Media.Play();
        }

        private void Btn_Start_Click(object sender, RoutedEventArgs e)
        {
            Media.Pause();
            string temp = musicList.First();
            Media.Source = new Uri(temp);
            lst_Music.SelectedItem = temp;
            Media.Play();
        }

        private void Btn_End_Click(object sender, RoutedEventArgs e)
        {
            Media.Pause();
            string temp = musicList.Last();
            Media.Source = new Uri(temp);
            lst_Music.SelectedItem = temp;
            Media.Play();
        }

        private void lst_Music_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Media.Pause();
            String find = lst_Music.SelectedItem.ToString();
            Media.Source = new Uri(find);
            Media.Play();
        }

        private void ShowLinkedList()
        {
            // clear list box
            lst_Music.Items.Clear();
            // display linked list
            foreach (string song in musicList)
                lst_Music.Items.Add(song);
        }
    }
}
