﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p454651_PQ6
{
    class Climate
    {
        public string Country { get; set; }
        public int Temp { get; set; }

        public Climate()
        {
        }
    }
}
