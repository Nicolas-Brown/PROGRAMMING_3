﻿using CsvHelper;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace p454651_PQ6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Climate> ClimateList;
        public Stream fileName;


        public MainWindow()
        {
            InitializeComponent();
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() == true)
            {
                var path = openFileDialog.FileName;
                fileName = new FileStream(path, FileMode.Create, FileAccess.ReadWrite);
                WriteFile();
                fileName = new FileStream(path, FileMode.Open, FileAccess.ReadWrite);
                ReadFile();
            }
            ToListBox(ClimateList);
        }

        public void ReadFile()
        {
            StreamReader reader = new StreamReader(fileName);
            CsvReader csv = new CsvReader(reader);
            var climate = csv.GetRecords<Climate>();
            ClimateList = climate.ToList();
            reader.Close();
        }

        public void WriteFile()
        {
            var climate = new List<Climate>
            {
            new Climate { Country = "Australia", Temp = 20 },
            new Climate { Country = "US", Temp = 18 },
            };

            StreamWriter writer = new StreamWriter(fileName);
            CsvWriter csv = new CsvWriter(writer);
            csv.WriteRecords(climate);
            writer.Close();
        }

        private void ToListBox(List<Climate> list)
        {
            foreach (Climate climate in list)
            {
                lst_Display.Items.Add(climate.Country + ", " + climate.Temp);
            }
        }
    }
}
