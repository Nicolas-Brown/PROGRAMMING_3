﻿using System;
using System.IO.Pipes;
using System.IO;

namespace p454651_PQ4_Client
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                using (PipeStream client = new AnonymousPipeClientStream(PipeDirection.In, args[0]))
                {
                    try
                    {
                        Console.WriteLine("[CLIENT] Setting ReadMode to \"Message\".");
                        client.ReadMode = PipeTransmissionMode.Message;
                    } 
                    catch (NotSupportedException e)
                    {
                    }

                    Console.WriteLine("[CLIENT] Current TransmissionMode: {0}", client.TransmissionMode);

                    using (StreamReader streamReader = new StreamReader(client))
                    {
                        string temp;
                        do
                        {
                            Console.WriteLine("[CLIENT] Wait for sync...");
                            temp = streamReader.ReadLine();
                        } while (!temp.StartsWith("Sync"));

                        while ((temp = streamReader.ReadLine()) != null)
                        {
                            Console.WriteLine("[CLIENT] Echo from server: " + temp);
                        }
                    }
                }
            }
            Console.Write("[CLIENT] Press Enter to close the program");
            Console.ReadLine();
            System.Environment.Exit(0);
        }
    }
}
