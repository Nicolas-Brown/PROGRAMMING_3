﻿using System;
using System.IO;
using System.IO.Pipes;
using System.Diagnostics;

namespace p454651_PQ4_Server
{
    class Program
    {
        static void Main()
        {
            bool userLogin = UserLogin();
            bool passLogin = PassLogin();
            if (passLogin == true && userLogin == true)
            {
                //run the server and client process
                Process client = new Process();
                client.StartInfo.FileName = "p454651_PQ4_Client.exe";

                //start the client
                using (AnonymousPipeServerStream server = new AnonymousPipeServerStream(PipeDirection.Out, HandleInheritability.Inheritable))
                {
                    try
                    {
                        Console.WriteLine("[SERVER] Setting ReadMode to \"Message\".");
                        server.ReadMode = PipeTransmissionMode.Message;
                    }
                    catch (NotSupportedException e)
                    {
                    }

                    Console.WriteLine("[SERVER] Current TransmissionMode: {0}.",
                        server.TransmissionMode);

                    client.StartInfo.Arguments = server.GetClientHandleAsString();
                    client.StartInfo.UseShellExecute = false;
                    client.Start();

                    server.DisposeLocalCopyOfClientHandle();

                    //Sync with server
                    try
                    {
                        using (StreamWriter streamWriter = new StreamWriter(server))
                        {
                            streamWriter.AutoFlush = true;
                            streamWriter.WriteLine("Sync");
                            server.WaitForPipeDrain();
                            Console.Write("[SERVER] Enter Text: ");
                            streamWriter.WriteLine(Console.ReadLine());
                        }
                    }
                    catch (IOException e)
                    {
                    }
                }
                //Close when finished
                client.WaitForExit();
                client.Close();
                Console.WriteLine("[SERVER] Client quit. Server terminating.");
            }
            else
            {
                //Redo login again
                Console.WriteLine("Details incorrect");
                Main();
            }
        }

        static void SavePass(string password)
        {
            //Save password to local file
            string file = "password.txt";
            StreamWriter streamWriter = new StreamWriter(file, false);
            streamWriter.WriteLine(password);
            streamWriter.Close();
        }

        static string RetrievePass()
        {
            //Retrieve password from local file
            string file = "password.txt";
            string line = "";
            string password = "";
            StreamReader streamReader = new StreamReader(file);
            while ((line = streamReader.ReadLine()) != null)
            {
                password = line;
            }
            streamReader.Close();
            return password;
        }

        static void SaveUser(string username)
        {
            //Save password to local file
            string file = "username.txt";
            StreamWriter streamWriter = new StreamWriter(file, false);
            streamWriter.WriteLine(username);
            streamWriter.Close();
        }

        static string RetrieveUser()
        {
            //Retrieve password from local file
            string file = "username.txt";
            string line = "";
            string username = "";
            StreamReader streamReader = new StreamReader(file);
            while ((line = streamReader.ReadLine()) != null)
            {
                username = line;
            }
            streamReader.Close();
            return username;
        }

        static bool PassLogin()
        {
            //Boolean state for login
            bool validated = false;
            Hasher hasher = new Hasher();

            Console.WriteLine("Enter password or type 'new' to change password:");
            string enteredPass = Console.ReadLine();

            if (enteredPass.Equals("new"))
            {
                Console.WriteLine("Enter new password:");
                enteredPass = Console.ReadLine();
                string hashedPass = hasher.Hashing(enteredPass);
                try
                {
                    SavePass(hashedPass);
                }
                catch (Exception e)
                {
                }
                return false;
            }
            else
            {
                string comparePass = RetrievePass();
                if (hasher.Verification(comparePass, enteredPass))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        static bool UserLogin()
        {
            //Boolean state for login
            bool validated = false;
            Hasher hasher = new Hasher();

            Console.WriteLine("Enter username or type 'new' to change username:");
            string eneteredUser = Console.ReadLine();

            if (eneteredUser.Equals("new"))
            {
                Console.WriteLine("Enter new username:");
                eneteredUser = Console.ReadLine();
                string hashedUser = hasher.Hashing(eneteredUser);
                try
                {
                    SaveUser(hashedUser);
                }
                catch (Exception e)
                {
                }
                return false;
            }
            
            else
            {
                string compareUser = RetrieveUser();
                if (hasher.Verification(compareUser, eneteredUser))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
